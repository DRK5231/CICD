Example CANoe test environment setup
